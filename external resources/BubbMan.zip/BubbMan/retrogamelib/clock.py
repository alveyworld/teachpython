import pygame

clock = pygame.time.Clock()

def tick():
    """ Tick the framerate -> return None
    """
    clock.tick(30)
