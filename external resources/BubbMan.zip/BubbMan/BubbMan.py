import sys
sys.path.insert(0, "gamelib")

import main
if __name__ == "__main__":
    main.main()
