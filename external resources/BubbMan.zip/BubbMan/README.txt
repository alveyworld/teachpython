BubbMan
~-~-~-~-~-~~-~-~-~-~-~

 A GameBoy-type platformer
 
 Copyright (C) 2009 - Licensed under the GNU LGPL
 
 Created by pymike and saluk
 Title Music by DrPetter
 In-Game music from ModArchive.Org

Story
~-~-~-~-~-~~-~-~-~-~-~

  BubbMan was on a trip to Oliland, when his car broke down in the 
 Dododu Mountains! BubbMan must cross the monster infested mountain 
 range to reach the safety of Oliland!

How to play
~-~-~-~-~-~~-~-~-~-~-~

 Use LEFT and RIGHT to move. Press the A button to jump;
 holding it longer will make you jump longer.
 
 Keyboard controls:
  A Button: Z key
  LEFT and RIGHT: Left and Right Arrow keys
  Start: Enter/Return

 Gamepad controls:
  A Button: 3 button
  LEFT and RIGHT: Hat/Dpad
  Start: Button 9
